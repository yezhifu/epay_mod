<?php

function epay_config() {
    $configarray = array(
     "FriendlyName" => array("Type" => "System", "Value"=>"EPay"),
     "pid" => array("FriendlyName" => "商户ID", "Type" => "text", "Size" => "10", ),
     "key" => array("FriendlyName" => "商户密钥", "Type" => "text", "Size" => "32", ),
    );
    return $configarray;
}

function epay_link($params) {

	$_input_charset  = "utf-8";
	$sign_type       = "MD5";
	$transport       = $params['transport']; 
	
	# Gateway Specific Variables
	$gatewaySELLER_ID = $params['seller_id'];
	$gatewaySELLER_KEY = $params['key'];
	$gatewayPID = $params['pid'];

	# Invoice Variables
	$invoiceid = $params['invoiceid'];
	$description = $params["description"];
	$amount = $params['amount']; # Format: ##.##

	# System Variables
	$companyname 		= $params['companyname'];
	$systemurl 			= $params['systemurl'];
	$return_url			= $systemurl."modules/gateways/epay/return.php";
	$notify_url			= $systemurl."modules/gateways/epay/notify.php";
	$info = array(					
		"return_url"      => $return_url,         				
		"notify_url"      => $notify_url,       				
		"subject"         => "$companyname-#$invoiceid",        	
		"body"            => $description,        				
		"out_order_no"    => $invoiceid,      				
		"total_fee"       => $amount,            				
	);

	$epay = new Epay($info,$gatewayPID,$gatewaySELLER_KEY);
	$code_ajax = $epay->get_code();

	$code = '<div class="alipay" style="max-width: 230px;margin: 0 auto"><div id="alipayimg" style="border: 1px solid #AAA;border-radius: 4px;overflow: hidden;margin-bottom: 5px;"><iframe width="300" height="292" frameborder="0" scrolling="no" style="transform: scale(.9);margin: -50px 0 -24px -37px;"></iframe></div>';
	$code = $code.$code_ajax;
	
	if (stristr($_SERVER['PHP_SELF'], 'viewinvoice')) {
		return $code;
	} else {
		return '<img style="width: 150px" src="'.$systemurl.'/modules/gateways/epay/logo.png" alt="易支付" />';
	}
}



class Epay {

	const apiurl = 'https://www.yiipay.xyz/';

	private $payment;

	private $order;

	public function __construct($order_info = array(),$partner,$key) {
		$this->order = $order_info;
		$this->payment = array(
			'partner' => $partner,
			'key' => $key,
		);
	}

	public function get_code() {
		
		$parameter = array(
			"pid" => trim($this->payment['partner']),
			"out_trade_no"	=> $this->order['out_order_no'],
			"name"	=> $this->order['subject'],
			"money"	=> $this->order['total_fee'],
			"notify_url"	=> $this->order['notify_url'],
			"return_url"	=> $this->order['return_url'],
			"sitename"	=> 'WHMCS'
		);

		$html_text = $this->buildRequestForm($parameter, $this->payment['key']);
		return $html_text;
	}

	public function notify_verify() {

		$Notify = $this->getSignVeryfy($_GET,$_GET['sign']);
		if($Notify) {
			if($_GET['trade_status']=='TRADE_SUCCESS'){
				return true;
			}else{
		    	return false;
			}
		}else {

		    return false;
		}
	}


	public function return_verify() {
		$Notify = $this->getSignVeryfy($_GET,$_GET['sign']);
		if($Notify) {
			if($_GET['trade_status']=='TRADE_SUCCESS'){
				return true;
			}else{
				return false;
			}
		}
		else {

		    return false;
		}
	}

	function getSignVeryfy($para_temp, $sign) {

		$para_filter = $this->paraFilter($para_temp);
		
		$para_sort = $this->argSort($para_filter);
		
		$prestr = $this->createLinkstring($para_sort);
		
		$isSgin = false;
		$isSgin = $this->md5Verify($prestr, $sign, $this->payment['key']);
	
		return $isSgin;
	}

	public function md5Verify($prestr, $sign, $key) {
		$prestr = $prestr . $key;
		$mysgin = md5($prestr);
		if($mysgin == $sign) {
			return true;
		}else {
			return false;
		}
	}


	public function buildRequestForm($para_temp,$key) {

		$para = $this->buildRequestPara($para_temp,$key);

		$sHtml = "<form id='paysubmit' name='paysubmit' action='".self::apiurl."submit.php' accept-charset='utf-8' method='POST'>";
		while (list ($key, $val) = each ($para)) {
	        $sHtml.= "<input type='hidden' name='".$key."' value='".$val."'/>";
	    }

	    $sHtml = $sHtml."<input type='submit'  value='支付进行中...' style='display:none;'></form>";
		
		$sHtml = $sHtml."<script>document.forms['paysubmit'].submit();</script>";
		
		return $sHtml;
	}

	public function buildRequestPara($para_temp,$key) {

		$para_filter = $this->paraFilter($para_temp);

		$para_sort = $this->argSort($para_filter);

		$mysign = $this->buildRequestMysign($para_sort,$key);
		
		$para_sort['sign'] = $mysign;
		
		return $para_sort;
	}

	public function paraFilter($para) {
		$para_filter = array();
		while (list ($key, $val) = each ($para)) {
			if($key == "sign" || $key == "sign_type" || $val == "")continue;
			else	$para_filter[$key] = $para[$key];
		}
		return $para_filter;
	}

	public function argSort($para) {
		ksort($para);
		reset($para);
		return $para;
	}

	public function buildRequestMysign($para_sort,$key) {

		$prestr = $this->createLinkstring($para_sort);
		$mysign = $this->md5Sign($prestr, $key);
		return $mysign;
	}
	public function md5Sign($prestr, $key) {
		$prestr = $prestr . $key;
		return md5($prestr);
	}

	public function createLinkstring($para) {
		$arg  = "";
		while (list ($key, $val) = each ($para)) {
			$arg.=$key."=".$val."&";
		}

		$arg = substr($arg,0,count($arg)-2);
		
		if(get_magic_quotes_gpc()){$arg = stripslashes($arg);}
		
		return $arg;
	}

}









?>